Setup and Launch:

Before launching game, extract .zip file to an external folder.

Launch the game from this folder (Back_to_Black_1.x.html).

DO NOT remove html file or supporting files from game folder.



NOTE:

The game was intended to have the back button disabled. We have included it for ease of marking.

Please be aware that due to issues with Twine, using the back button will cause the background music to cut out until the next player respawn.