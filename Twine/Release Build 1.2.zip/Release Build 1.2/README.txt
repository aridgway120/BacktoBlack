Before launching game, extract .zip file to an external folder.
Launch the game from this folder (Back_to_Black_1.x.html).

DO NOT remove html file or supporting files from game folder.